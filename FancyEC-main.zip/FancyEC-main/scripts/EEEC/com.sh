
# python  td3.py --task Hopper-v3 --epoch 400
# pkill -f td3
# python  eeec_td3.py --task Hopper-v3 --epoch 400 --tokens 5
# pkill -f eeec


python  eeec_td3.py --task Hopper-v3 --epoch 800 
pkill -f eeec
python  eeec_td3.py --task Hopper-v3 --epoch 800 
pkill -f eeec
python  eeec_td3.py --task Hopper-v3 --epoch 800 
pkill -f eeec


# python  eeec_td3.py --task Walker2d-v3 --epoch 400 
# pkill -f eeec
# python  eeec_td3.py --task Walker2d-v3 --epoch 400 
# pkill -f eeec
# python  eeec_td3.py --task Walker2d-v3 --epoch 400 
# pkill -f eeec

# python  eeec_td3.py --task Swimmer-v3 --epoch 200 
# pkill -f eeec
# python  eeec_td3.py --task Swimmer-v3 --epoch 200 
# pkill -f eeec
# python  eeec_td3.py --task Swimmer-v3 --epoch 200 
# pkill -f eeec


# python  eeec_td3.py --task Ant-v3 --epoch 1000 
# pkill -f eeec
# python  eeec_td3.py --task Ant-v3 --epoch 1000 
# pkill -f eeec
# python  eeec_td3.py --task Ant-v3 --epoch 1000 
# pkill -f eeec

# python  eeec_td3.py --task Humanoid-v3 --epoch 1000 
# pkill -f eeec
# python  eeec_td3.py --task Humanoid-v3 --epoch 1000 
# pkill -f eeec
# python  eeec_td3.py --task Humanoid-v3 --epoch 1000 
# pkill -f eeec

# python  eeec_td3.py --task HalfCheetah-v3 --epoch 1000 
# pkill -f eeec
# python  eeec_td3.py --task HalfCheetah-v3 --epoch 1000 
# pkill -f eeec
# python  eeec_td3.py --task HalfCheetah-v3 --epoch 1000 
# pkill -f eeec