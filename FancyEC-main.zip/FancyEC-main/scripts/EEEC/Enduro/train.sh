python eeec_rainbow.py --task EnduroNoFrameskip-v4  --epoch 500
python eeec_rainbow.py --task EnduroNoFrameskip-v4  --epoch 500 