python dqn.py --task EnduroNoFrameskip-v4 --epoch 500
killall -9 python
python dqn.py --task EnduroNoFrameskip-v4 --epoch 500
killall -9 python
python dqn.py --task EnduroNoFrameskip-v4 --epoch 500
killall -9 python
python dqn.py --task EnduroNoFrameskip-v4 --epoch 500
killall -9 python
python dqn.py --task EnduroNoFrameskip-v4 --epoch 500
killall -9 python

python rainbow.py --task EnduroNoFrameskip-v4 --epoch 500
killall -9 python
python rainbow.py --task EnduroNoFrameskip-v4 --epoch 500
killall -9 python
python rainbow.py --task EnduroNoFrameskip-v4 --epoch 500
killall -9 python
python rainbow.py --task EnduroNoFrameskip-v4 --epoch 500
killall -9 python
python rainbow.py --task EnduroNoFrameskip-v4 --epoch 500
killall -9 python

