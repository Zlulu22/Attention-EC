
python necsa_td3.py --task Walker2d-v3 --epoch 400 --step 4 --grid_num 5 --epsilon 0.1 
pkill -f necsa
python necsa_td3.py --task Walker2d-v3 --epoch 400 --step 4 --grid_num 5 --epsilon 0.1 
pkill -f necsa
python necsa_td3.py --task Walker2d-v3 --epoch 400 --step 4 --grid_num 5 --epsilon 0.1 
pkill -f necsa

python necsa_td3.py --task Walker2d-v3 --epoch 400 --step 5 --grid_num 5 --epsilon 0.1 
pkill -f necsa
python necsa_td3.py --task Walker2d-v3 --epoch 400 --step 5 --grid_num 5 --epsilon 0.1 
pkill -f necsa
python necsa_td3.py --task Walker2d-v3 --epoch 400 --step 5 --grid_num 5 --epsilon 0.1 
pkill -f necsa

python necsa_td3.py --task Walker2d-v3 --epoch 400 --step 6 --grid_num 5 --epsilon 0.1 
pkill -f necsa
python necsa_td3.py --task Walker2d-v3 --epoch 400 --step 6 --grid_num 5 --epsilon 0.1 
pkill -f necsa
python necsa_td3.py --task Walker2d-v3 --epoch 400 --step 6 --grid_num 5 --epsilon 0.1 
pkill -f necsa