python dqn.py --task MsPacmanNoFrameskip-v4 --epoch 500
killall -9 python
python dqn.py --task MsPacmanNoFrameskip-v4 --epoch 500
killall -9 python
python dqn.py --task MsPacmanNoFrameskip-v4 --epoch 500
killall -9 python
python dqn.py --task MsPacmanNoFrameskip-v4 --epoch 500
killall -9 python
python dqn.py --task MsPacmanNoFrameskip-v4 --epoch 500
killall -9 python


python rainbow.py --task MsPacmanNoFrameskip-v4 --epoch 500
killall -9 python
python rainbow.py --task MsPacmanNoFrameskip-v4 --epoch 500
killall -9 python
python rainbow.py --task MsPacmanNoFrameskip-v4 --epoch 500
killall -9 python
python rainbow.py --task MsPacmanNoFrameskip-v4 --epoch 500
killall -9 python
python rainbow.py --task MsPacmanNoFrameskip-v4 --epoch 500
killall -9 python
