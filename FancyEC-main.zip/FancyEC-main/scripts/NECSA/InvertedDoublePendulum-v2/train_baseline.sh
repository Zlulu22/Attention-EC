python ddpg.py --task InvertedDoublePendulum-v2 --epoch 100
pkill -f ddpg
python ddpg.py --task InvertedDoublePendulum-v2 --epoch 100
pkill -f ddpg
python ddpg.py --task InvertedDoublePendulum-v2 --epoch 100
pkill -f ddpg
python ddpg.py --task InvertedDoublePendulum-v2 --epoch 100
pkill -f ddpg
python ddpg.py --task InvertedDoublePendulum-v2 --epoch 100
pkill -f ddpg




python td3.py --task InvertedDoublePendulum-v2 --epoch 100
pkill -f td3
python td3.py --task InvertedDoublePendulum-v2 --epoch 100
pkill -f td3
python td3.py --task InvertedDoublePendulum-v2 --epoch 100
pkill -f td3
python td3.py --task InvertedDoublePendulum-v2 --epoch 100
pkill -f td3
python td3.py --task InvertedDoublePendulum-v2 --epoch 100
pkill -f td3