

python  eeec_td3.py --task Hopper-v3 --epoch 400 --score-rate 0.01
python  eeec_td3.py --task Hopper-v3 --epoch 400 --score-rate 0.01
python  eeec_td3.py --task Hopper-v3 --epoch 400 --score-rate 0.01

python  eeec_td3.py --task Hopper-v3 --epoch 400 --score-rate 0.1
python  eeec_td3.py --task Hopper-v3 --epoch 400 --score-rate 0.1
python  eeec_td3.py --task Hopper-v3 --epoch 400 --score-rate 0.1

python  eeec_td3.py --task Hopper-v3 --epoch 400 --score-rate 0.2
python  eeec_td3.py --task Hopper-v3 --epoch 400 --score-rate 0.2
python  eeec_td3.py --task Hopper-v3 --epoch 400 --score-rate 0.2

python  eeec_td3.py --task Hopper-v3 --epoch 400 --score-rate 0.5
python  eeec_td3.py --task Hopper-v3 --epoch 400 --score-rate 0.5
python  eeec_td3.py --task Hopper-v3 --epoch 400 --score-rate 0.5

python  eeec_td3.py --task Hopper-v3 --epoch 400 --score-rate 1
python  eeec_td3.py --task Hopper-v3 --epoch 400 --score-rate 1
python  eeec_td3.py --task Hopper-v3 --epoch 400 --score-rate 1


