python necsa_td3.py --task Walker2d-v3 --epoch 400 --step 1 --grid_num 5 --epsilon 0.2 --mode state_action
pkill -f necsa
python necsa_td3.py --task Walker2d-v3 --epoch 400 --step 1 --grid_num 5 --epsilon 0.2 --mode state_action
pkill -f necsa
python necsa_td3.py --task Walker2d-v3 --epoch 400 --step 1 --grid_num 5 --epsilon 0.2 --mode state_action
pkill -f necsa
python necsa_td3.py --task Walker2d-v3 --epoch 400 --step 1 --grid_num 5 --epsilon 0.2 --mode state_action
pkill -f necsa
python necsa_td3.py --task Walker2d-v3 --epoch 400 --step 1 --grid_num 5 --epsilon 0.2 --mode state_action
pkill -f necsa


python necsa_td3.py --task Walker2d-v3 --epoch 400 --step 2 --grid_num 5 --epsilon 0.2 --mode state_action
pkill -f necsa
python necsa_td3.py --task Walker2d-v3 --epoch 400 --step 2 --grid_num 5 --epsilon 0.2 --mode state_action
pkill -f necsa
python necsa_td3.py --task Walker2d-v3 --epoch 400 --step 2 --grid_num 5 --epsilon 0.2 --mode state_action
pkill -f necsa
python necsa_td3.py --task Walker2d-v3 --epoch 400 --step 2 --grid_num 5 --epsilon 0.2 --mode state_action
pkill -f necsa
python necsa_td3.py --task Walker2d-v3 --epoch 400 --step 2 --grid_num 5 --epsilon 0.2 --mode state_action
pkill -f necsa

python necsa_td3.py --task Walker2d-v3 --epoch 400 --step 3 --grid_num 5 --epsilon 0.2 --mode state_action
pkill -f necsa
python necsa_td3.py --task Walker2d-v3 --epoch 400 --step 3 --grid_num 5 --epsilon 0.2 --mode state_action
pkill -f necsa
python necsa_td3.py --task Walker2d-v3 --epoch 400 --step 3 --grid_num 5 --epsilon 0.2 --mode state_action
pkill -f necsa
python necsa_td3.py --task Walker2d-v3 --epoch 400 --step 3 --grid_num 5 --epsilon 0.2 --mode state_action
pkill -f necsa
python necsa_td3.py --task Walker2d-v3 --epoch 400 --step 3 --grid_num 5 --epsilon 0.2 --mode state_action
pkill -f necsa