python necsa_td3.py --task Reacher-v2 --epoch 100 --step 1 --grid_num 10 --state_min -6 --state_max 6 --epsilon 0.1 --mode state_action
pkill -f necsa
python necsa_td3.py --task Reacher-v2 --epoch 100 --step 1 --grid_num 10 --state_min -6 --state_max 6 --epsilon 0.1 --mode state_action
pkill -f necsa
python necsa_td3.py --task Reacher-v2 --epoch 100 --step 1 --grid_num 10 --state_min -6 --state_max 6 --epsilon 0.1 --mode state_action
pkill -f necsa
python necsa_td3.py --task Reacher-v2 --epoch 100 --step 1 --grid_num 10 --state_min -6 --state_max 6 --epsilon 0.1 --mode state_action
pkill -f necsa
python necsa_td3.py --task Reacher-v2 --epoch 100 --step 1 --grid_num 10 --state_min -6 --state_max 6 --epsilon 0.1 --mode state_action
pkill -f necsa


python necsa_td3.py --task Reacher-v2 --epoch 100 --step 2 --grid_num 10 --state_min -6 --state_max 6 --epsilon 0.1 --mode state_action
pkill -f necsa
python necsa_td3.py --task Reacher-v2 --epoch 100 --step 2 --grid_num 10 --state_min -6 --state_max 6 --epsilon 0.1 --mode state_action
pkill -f necsa
python necsa_td3.py --task Reacher-v2 --epoch 100 --step 2 --grid_num 10 --state_min -6 --state_max 6 --epsilon 0.1 --mode state_action
pkill -f necsa
python necsa_td3.py --task Reacher-v2 --epoch 100 --step 2 --grid_num 10 --state_min -6 --state_max 6 --epsilon 0.1 --mode state_action
pkill -f necsa
python necsa_td3.py --task Reacher-v2 --epoch 100 --step 2 --grid_num 10 --state_min -6 --state_max 6 --epsilon 0.1 --mode state_action
pkill -f necsa

python necsa_td3.py --task Reacher-v2 --epoch 100 --step 3 --grid_num 10 --state_min -6 --state_max 6 --epsilon 0.1 --mode state_action
pkill -f necsa
python necsa_td3.py --task Reacher-v2 --epoch 100 --step 3 --grid_num 10 --state_min -6 --state_max 6 --epsilon 0.1 --mode state_action
pkill -f necsa
python necsa_td3.py --task Reacher-v2 --epoch 100 --step 3 --grid_num 10 --state_min -6 --state_max 6 --epsilon 0.1 --mode state_action
pkill -f necsa
python necsa_td3.py --task Reacher-v2 --epoch 100 --step 3 --grid_num 10 --state_min -6 --state_max 6 --epsilon 0.1 --mode state_action
pkill -f necsa
python necsa_td3.py --task Reacher-v2 --epoch 100 --step 3 --grid_num 10 --state_min -6 --state_max 6 --epsilon 0.1 --mode state_action
pkill -f necsa