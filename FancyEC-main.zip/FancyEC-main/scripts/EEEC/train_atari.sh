python  eeec_rainbow.py --task EnduroNoFrameskip-v4 --epoch 500 --score-rate 0.01
python  eeec_rainbow.py --task EnduroNoFrameskip-v4 --epoch 500 --score-rate 0.01
python  eeec_rainbow.py --task EnduroNoFrameskip-v4 --epoch 500 --score-rate 0.01


python  eeec_rainbow.py --task EnduroNoFrameskip-v4 --epoch 500 --score-rate 0.05
python  eeec_rainbow.py --task EnduroNoFrameskip-v4 --epoch 500 --score-rate 0.05
python  eeec_rainbow.py --task EnduroNoFrameskip-v4 --epoch 500 --score-rate 0.05

python  eeec_rainbow.py --task EnduroNoFrameskip-v4 --epoch 500 --score-rate 0.1
python  eeec_rainbow.py --task EnduroNoFrameskip-v4 --epoch 500 --score-rate 0.1
python  eeec_rainbow.py --task EnduroNoFrameskip-v4 --epoch 500 --score-rate 0.1

python  eeec_rainbow.py --task EnduroNoFrameskip-v4 --epoch 500 --score-rate 0.5
python  eeec_rainbow.py --task EnduroNoFrameskip-v4 --epoch 500 --score-rate 0.5
python  eeec_rainbow.py --task EnduroNoFrameskip-v4 --epoch 500 --score-rate 0.5

python  eeec_rainbow.py --task EnduroNoFrameskip-v4 --epoch 500 --score-rate 1.0
python  eeec_rainbow.py --task EnduroNoFrameskip-v4 --epoch 500 --score-rate 1.0
python  eeec_rainbow.py --task EnduroNoFrameskip-v4 --epoch 500 --score-rate 1.0
