# python necsa_ddpg.py --task HalfCheetah-v3 --epoch 1000 --step 1 --grid_num 6 --state_min -6 --state_max 6 --epsilon 0.2 --mode state_action
# pkill -f necsa
# python necsa_ddpg.py --task HalfCheetah-v3 --epoch 1000 --step 1 --grid_num 6 --state_min -6 --state_max 6 --epsilon 0.2 --mode state_action
# pkill -f necsa
# python necsa_ddpg.py --task HalfCheetah-v3 --epoch 1000 --step 1 --grid_num 6 --state_min -6 --state_max 6 --epsilon 0.2 --mode state_action
# pkill -f necsa
# python necsa_ddpg.py --task HalfCheetah-v3 --epoch 1000 --step 1 --grid_num 6 --state_min -6 --state_max 6 --epsilon 0.2 --mode state_action
# pkill -f necsa
# python necsa_ddpg.py --task HalfCheetah-v3 --epoch 1000 --step 1 --grid_num 6 --state_min -6 --state_max 6 --epsilon 0.2 --mode state_action
# pkill -f necsa


# python necsa_ddpg.py --task HalfCheetah-v3 --epoch 1000 --step 2 --grid_num 6 --state_min -6 --state_max 6 --epsilon 0.2 --mode state_action
# pkill -f necsa
# python necsa_ddpg.py --task HalfCheetah-v3 --epoch 1000 --step 2 --grid_num 6 --state_min -6 --state_max 6 --epsilon 0.2 --mode state_action
# pkill -f necsa
# python necsa_ddpg.py --task HalfCheetah-v3 --epoch 1000 --step 2 --grid_num 6 --state_min -6 --state_max 6 --epsilon 0.2 --mode state_action
# pkill -f necsa
# python necsa_ddpg.py --task HalfCheetah-v3 --epoch 1000 --step 2 --grid_num 6 --state_min -6 --state_max 6 --epsilon 0.2 --mode state_action
# pkill -f necsa
# python necsa_ddpg.py --task HalfCheetah-v3 --epoch 1000 --step 2 --grid_num 6 --state_min -6 --state_max 6 --epsilon 0.2 --mode state_action
# pkill -f necsa

python necsa_ddpg.py --task HalfCheetah-v3 --epoch 1000 --step 3 --grid_num 6 --state_min -6 --state_max 6 --epsilon 0.4 --mode state_action
pkill -f necsa
python necsa_ddpg.py --task HalfCheetah-v3 --epoch 1000 --step 3 --grid_num 6 --state_min -6 --state_max 6 --epsilon 0.4 --mode state_action
pkill -f necsa
python necsa_ddpg.py --task HalfCheetah-v3 --epoch 1000 --step 3 --grid_num 6 --state_min -6 --state_max 6 --epsilon 0.4 --mode state_action
pkill -f necsa
python necsa_ddpg.py --task HalfCheetah-v3 --epoch 1000 --step 3 --grid_num 6 --state_min -6 --state_max 6 --epsilon 0.4 --mode state_action
pkill -f necsa
python necsa_ddpg.py --task HalfCheetah-v3 --epoch 1000 --step 3 --grid_num 6 --state_min -6 --state_max 6 --epsilon 0.4 --mode state_action
pkill -f necsa

