python necsa_rainbow.py --task QbertNoFrameskip-v4  --epoch 500 --step 1 --epsilon 0.1 --mode hidden --reduction
killall -9 python
python necsa_rainbow.py --task QbertNoFrameskip-v4  --epoch 500 --step 1 --epsilon 0.1 --mode hidden --reduction
killall -9 python
python necsa_rainbow.py --task QbertNoFrameskip-v4  --epoch 500 --step 1 --epsilon 0.1 --mode hidden --reduction
killall -9 python
python necsa_rainbow.py --task QbertNoFrameskip-v4  --epoch 500 --step 1 --epsilon 0.1 --mode hidden --reduction
killall -9 python
python necsa_rainbow.py --task QbertNoFrameskip-v4  --epoch 500 --step 1 --epsilon 0.1 --mode hidden --reduction
killall -9 python



python necsa_rainbow.py --task QbertNoFrameskip-v4  --epoch 500 --step 2 --epsilon 0.1 --mode hidden --reduction
killall -9 python
python necsa_rainbow.py --task QbertNoFrameskip-v4  --epoch 500 --step 2 --epsilon 0.1 --mode hidden --reduction
killall -9 python
python necsa_rainbow.py --task QbertNoFrameskip-v4  --epoch 500 --step 2 --epsilon 0.1 --mode hidden --reduction
killall -9 python
python necsa_rainbow.py --task QbertNoFrameskip-v4  --epoch 500 --step 2 --epsilon 0.1 --mode hidden --reduction
killall -9 python
python necsa_rainbow.py --task QbertNoFrameskip-v4  --epoch 500 --step 2 --epsilon 0.1 --mode hidden --reduction
killall -9 python

python necsa_rainbow.py --task QbertNoFrameskip-v4  --epoch 500 --step 3 --epsilon 0.1 --mode hidden --reduction
killall -9 python
python necsa_rainbow.py --task QbertNoFrameskip-v4  --epoch 500 --step 3 --epsilon 0.1 --mode hidden --reduction
killall -9 python
python necsa_rainbow.py --task QbertNoFrameskip-v4  --epoch 500 --step 3 --epsilon 0.1 --mode hidden --reduction
killall -9 python
python necsa_rainbow.py --task QbertNoFrameskip-v4  --epoch 500 --step 3 --epsilon 0.1 --mode hidden --reduction
killall -9 python
python necsa_rainbow.py --task QbertNoFrameskip-v4  --epoch 500 --step 3 --epsilon 0.1 --mode hidden --reduction
killall -9 python
