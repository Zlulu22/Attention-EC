python necsa_td3.py --task Humanoid-v3  --epoch 1000 --step 1 --grid_num 6 --state_dim 24 --state_min -6 --state_max 6 --epsilon 0.2 --mode state_action --reduction
killall -9 python
python necsa_td3.py --task Humanoid-v3  --epoch 1000 --step 1 --grid_num 6 --state_dim 24 --state_min -6 --state_max 6 --epsilon 0.2 --mode state_action --reduction
killall -9 python
python necsa_td3.py --task Humanoid-v3  --epoch 1000 --step 1 --grid_num 6 --state_dim 24 --state_min -6 --state_max 6 --epsilon 0.2 --mode state_action --reduction
killall -9 python
python necsa_td3.py --task Humanoid-v3  --epoch 1000 --step 1 --grid_num 6 --state_dim 24 --state_min -6 --state_max 6 --epsilon 0.2 --mode state_action --reduction
killall -9 python
python necsa_td3.py --task Humanoid-v3  --epoch 1000 --step 1 --grid_num 6 --state_dim 24 --state_min -6 --state_max 6 --epsilon 0.2 --mode state_action --reduction
killall -9 python


python necsa_td3.py --task Humanoid-v3  --epoch 1000 --step 2 --grid_num 6 --state_dim 24 --state_min -6 --state_max 6 --epsilon 0.2 --mode state_action --reduction
killall -9 python
python necsa_td3.py --task Humanoid-v3  --epoch 1000 --step 2 --grid_num 6 --state_dim 24 --state_min -6 --state_max 6 --epsilon 0.2 --mode state_action --reduction
killall -9 python
python necsa_td3.py --task Humanoid-v3  --epoch 1000 --step 2 --grid_num 6 --state_dim 24 --state_min -6 --state_max 6 --epsilon 0.2 --mode state_action --reduction
killall -9 python
python necsa_td3.py --task Humanoid-v3  --epoch 1000 --step 2 --grid_num 6 --state_dim 24 --state_min -6 --state_max 6 --epsilon 0.2 --mode state_action --reduction
killall -9 python
python necsa_td3.py --task Humanoid-v3  --epoch 1000 --step 2 --grid_num 6 --state_dim 24 --state_min -6 --state_max 6 --epsilon 0.2 --mode state_action --reduction
killall -9 python

python necsa_td3.py --task Humanoid-v3  --epoch 1000 --step 3 --grid_num 6 --state_dim 24 --state_min -6 --state_max 6 --epsilon 0.3 --mode state_action --reduction
killall -9 python
python necsa_td3.py --task Humanoid-v3  --epoch 1000 --step 3 --grid_num 6 --state_dim 24 --state_min -6 --state_max 6 --epsilon 0.3 --mode state_action --reduction
killall -9 python
python necsa_td3.py --task Humanoid-v3  --epoch 1000 --step 3 --grid_num 6 --state_dim 24 --state_min -6 --state_max 6 --epsilon 0.3 --mode state_action --reduction
killall -9 python
python necsa_td3.py --task Humanoid-v3  --epoch 1000 --step 3 --grid_num 6 --state_dim 24 --state_min -6 --state_max 6 --epsilon 0.3 --mode state_action --reduction
killall -9 python
python necsa_td3.py --task Humanoid-v3  --epoch 1000 --step 3 --grid_num 6 --state_dim 24 --state_min -6 --state_max 6 --epsilon 0.3 --mode state_action --reduction
killall -9 python