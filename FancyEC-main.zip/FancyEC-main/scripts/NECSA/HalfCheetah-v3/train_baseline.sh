python ddpg.py --task HalfCheetah-v3 --epoch 1000
pkill -f ddpg
python ddpg.py --task HalfCheetah-v3 --epoch 1000
pkill -f ddpg
python ddpg.py --task HalfCheetah-v3 --epoch 1000
pkill -f ddpg
python ddpg.py --task HalfCheetah-v3 --epoch 1000
pkill -f ddpg
python ddpg.py --task HalfCheetah-v3 --epoch 1000
pkill -f ddpg


python td3.py --task HalfCheetah-v3 --epoch 1000
pkill -f td3
python td3.py --task HalfCheetah-v3 --epoch 1000
pkill -f td3
python td3.py --task HalfCheetah-v3 --epoch 1000
pkill -f td3
python td3.py --task HalfCheetah-v3 --epoch 1000
pkill -f td3
python td3.py --task HalfCheetah-v3 --epoch 1000
pkill -f td3