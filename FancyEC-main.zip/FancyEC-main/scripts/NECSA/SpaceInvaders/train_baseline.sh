python dqn.py --task SpaceInvadersNoFrameskip-v4 --epoch 500
killall -9 python
python dqn.py --task SpaceInvadersNoFrameskip-v4 --epoch 500
killall -9 python
python dqn.py --task SpaceInvadersNoFrameskip-v4 --epoch 500
killall -9 python
python dqn.py --task SpaceInvadersNoFrameskip-v4 --epoch 500
killall -9 python
python dqn.py --task SpaceInvadersNoFrameskip-v4 --epoch 500
killall -9 python

python rainbow.py --task SpaceInvadersNoFrameskip-v4 --epoch 500
killall -9 python
python rainbow.py --task SpaceInvadersNoFrameskip-v4 --epoch 500
killall -9 python
python rainbow.py --task SpaceInvadersNoFrameskip-v4 --epoch 500
killall -9 python
python rainbow.py --task SpaceInvadersNoFrameskip-v4 --epoch 500
killall -9 python
python rainbow.py --task SpaceInvadersNoFrameskip-v4 --epoch 500
killall -9 python

