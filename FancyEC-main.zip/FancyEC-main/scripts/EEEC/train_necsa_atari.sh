# python necsa_rainbow.py --task AlienNoFrameskip-v4  --epoch 500 --step 3 --epsilon 0.1 --mode hidden --reduction
# killall -9 AlienNoFrameskip
# python necsa_rainbow.py --task AlienNoFrameskip-v4  --epoch 500 --step 3 --epsilon 0.1 --mode hidden --reduction
# killall -9 AlienNoFrameskip
# python necsa_rainbow.py --task AlienNoFrameskip-v4  --epoch 500 --step 3 --epsilon 0.1 --mode hidden --reduction
# killall -9 AlienNoFrameskip


python necsa_rainbow.py --task BreakoutNoFrameskip-v4  --epoch 500 --step 3 --epsilon 0.1 --mode hidden --reduction
killall -9 BreakoutNoFrameskip
python necsa_rainbow.py --task BreakoutNoFrameskip-v4  --epoch 500 --step 3 --epsilon 0.1 --mode hidden --reduction
killall -9 BreakoutNoFrameskip
python necsa_rainbow.py --task BreakoutNoFrameskip-v4  --epoch 500 --step 3 --epsilon 0.1 --mode hidden --reduction
killall -9 BreakoutNoFrameskip


# python necsa_rainbow.py --task EnduroNoFrameskip-v4  --epoch 500 --step 3 --epsilon 0.1 --mode hidden --reduction
# killall -9 EnduroNoFrameskip
# python necsa_rainbow.py --task EnduroNoFrameskip-v4  --epoch 500 --step 3 --epsilon 0.1 --mode hidden --reduction
# killall -9 EnduroNoFrameskip
# python necsa_rainbow.py --task EnduroNoFrameskip-v4  --epoch 500 --step 3 --epsilon 0.1 --mode hidden --reduction
# killall -9 EnduroNoFrameskip


# python necsa_rainbow.py --task MsPacmanNoFrameskip-v4  --epoch 500 --step 3 --epsilon 0.1 --mode hidden --reduction
# killall -9 MsPacmanNoFrameskip
# python necsa_rainbow.py --task MsPacmanNoFrameskip-v4  --epoch 500 --step 3 --epsilon 0.1 --mode hidden --reduction
# killall -9 MsPacmanNoFrameskip
# python necsa_rainbow.py --task MsPacmanNoFrameskip-v4  --epoch 500 --step 3 --epsilon 0.1 --mode hidden --reduction
# killall -9 MsPacmanNoFrameskip


# python necsa_rainbow.py --task QbertNoFrameskip-v4  --epoch 500 --step 3 --epsilon 0.1 --mode hidden --reduction
# killall -9 QbertNoFrameskip
# python necsa_rainbow.py --task QbertNoFrameskip-v4  --epoch 500 --step 3 --epsilon 0.1 --mode hidden --reduction
# killall -9 QbertNoFrameskip
# python necsa_rainbow.py --task QbertNoFrameskip-v4  --epoch 500 --step 3 --epsilon 0.1 --mode hidden --reduction
# killall -9 QbertNoFrameskip


# python necsa_rainbow.py --task SpaceInvadersNoFrameskip-v4  --epoch 500 --step 3 --epsilon 0.1 --mode hidden --reduction
# killall -9 SpaceInvadersNoFrameskip
# python necsa_rainbow.py --task SpaceInvadersNoFrameskip-v4  --epoch 500 --step 3 --epsilon 0.1 --mode hidden --reduction
# killall -9 SpaceInvadersNoFrameskip
# python necsa_rainbow.py --task SpaceInvadersNoFrameskip-v4  --epoch 500 --step 3 --epsilon 0.1 --mode hidden --reduction
# killall -9 SpaceInvadersNoFrameskip


