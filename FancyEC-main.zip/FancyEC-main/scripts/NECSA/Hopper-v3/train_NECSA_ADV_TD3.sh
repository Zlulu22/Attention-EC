python necsa_adv_td3.py --task Hopper-v3  --epoch 400 --step 1 --grid_num 5 --epsilon 0.1 
pkill -f necsa
python necsa_adv_td3.py --task Hopper-v3  --epoch 400 --step 1 --grid_num 5 --epsilon 0.1 
pkill -f necsa
python necsa_adv_td3.py --task Hopper-v3  --epoch 400 --step 1 --grid_num 5 --epsilon 0.1 
pkill -f necsa
python necsa_adv_td3.py --task Hopper-v3  --epoch 400 --step 1 --grid_num 5 --epsilon 0.1 
pkill -f necsa
python necsa_adv_td3.py --task Hopper-v3  --epoch 400 --step 1 --grid_num 5 --epsilon 0.1 
pkill -f necsa


python necsa_adv_td3.py --task Hopper-v3  --epoch 400 --step 2 --grid_num 5 --epsilon 0.1 
pkill -f necsa
python necsa_adv_td3.py --task Hopper-v3  --epoch 400 --step 2 --grid_num 5 --epsilon 0.1 
pkill -f necsa
python necsa_adv_td3.py --task Hopper-v3  --epoch 400 --step 2 --grid_num 5 --epsilon 0.1 
pkill -f necsa
python necsa_adv_td3.py --task Hopper-v3  --epoch 400 --step 2 --grid_num 5 --epsilon 0.1 
pkill -f necsa
python necsa_adv_td3.py --task Hopper-v3  --epoch 400 --step 2 --grid_num 5 --epsilon 0.1 
pkill -f necsa

python necsa_adv_td3.py --task Hopper-v3  --epoch 400 --step 3 --grid_num 5 --epsilon 0.1 
pkill -f necsa
python necsa_adv_td3.py --task Hopper-v3  --epoch 400 --step 3 --grid_num 5 --epsilon 0.1 
pkill -f necsa
python necsa_adv_td3.py --task Hopper-v3  --epoch 400 --step 3 --grid_num 5 --epsilon 0.1 
pkill -f necsa
python necsa_adv_td3.py --task Hopper-v3  --epoch 400 --step 3 --grid_num 5 --epsilon 0.1 
pkill -f necsa
python necsa_adv_td3.py --task Hopper-v3  --epoch 400 --step 3 --grid_num 5 --epsilon 0.1 
pkill -f necsa